export const applyCustomCode = (externalCodeSetup: any) => {
	// call custom code api here
};